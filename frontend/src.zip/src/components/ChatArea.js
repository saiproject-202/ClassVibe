// src/components/ChatArea.jsx
import React, { useRef, useEffect, useState } from 'react';
import socket from '../socket';

const ChatArea = ({ 
  messages, 
  currentUserId, 
  typingUsers, 
  onSessionEnded,
  onMessageEdited,
  onMessageDeleted 
}) => {
  // References and State
  const messagesEndRef = useRef(null);
  const messagesContainerRef = useRef(null);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [contextMenu, setContextMenu] = useState(null);
  
  // Session state
  const [sessionActive, setSessionActive] = useState(true);
  const [sessionInfo, setSessionInfo] = useState(null);
  
  // Search functionality
  const [searchQuery, setSearchQuery] = useState('');
  
  // Editing state
  const [editingMessageId, setEditingMessageId] = useState(null);
  const [editText, setEditText] = useState('');

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // ✅ Socket listeners for session ended, edit, delete
  useEffect(() => {
    const handleSessionEnded = (data) => {
      setSessionActive(false);
      setSessionInfo(data ?? { message: 'This session has been ended by the teacher.' });
      if (typeof onSessionEnded === 'function') {
        try { 
          onSessionEnded(data); 
        } catch (e) { 
          console.warn('onSessionEnded callback error', e); 
        }
      }
    };

    // ✅ NEW: Listen for message edited
    const handleMessageEdited = (editedMessage) => {
      console.log('Message edited received:', editedMessage);
      if (typeof onMessageEdited === 'function') {
        onMessageEdited(editedMessage);
      }
      // Clear editing state if this was the message being edited
      if (editingMessageId === editedMessage._id) {
        setEditingMessageId(null);
        setEditText('');
      }
    };

    // ✅ NEW: Listen for message deleted
    const handleMessageDeleted = (data) => {
      console.log('Message deleted received:', data);
      if (typeof onMessageDeleted === 'function') {
        onMessageDeleted(data.messageId);
      }
    };

    socket.on('sessionEnded', handleSessionEnded);
    socket.on('messageEdited', handleMessageEdited);
    socket.on('messageDeleted', handleMessageDeleted);

    return () => {
      socket.off('sessionEnded', handleSessionEnded);
      socket.off('messageEdited', handleMessageEdited);
      socket.off('messageDeleted', handleMessageDeleted);
    };
  }, [onSessionEnded, onMessageEdited, onMessageDeleted, editingMessageId]);

  // Check if user scrolled up
  const handleScroll = () => {
    const container = messagesContainerRef.current;
    if (container) {
      const isNearBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 100;
      setShowScrollButton(!isNearBottom);
    }
  };

  const scrollToBottom = (smooth = true) => {
    messagesEndRef.current?.scrollIntoView({
      behavior: smooth ? 'smooth' : 'auto'
    });
  };

  // Format time
  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();

    if (isToday) {
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
      });
    } else {
      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    }
  };

  // Get date separator text
  const getDateSeparator = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === now.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric'
      });
    }
  };

  // Check if we need a date separator
  const needsDateSeparator = (currentMsg, previousMsg) => {
    if (!previousMsg) return true;

    const currentDate = new Date(currentMsg.createdAt).toDateString();
    const previousDate = new Date(previousMsg.createdAt).toDateString();

    return currentDate !== previousDate;
  };

  // Get user initials
  const getInitials = (username) => {
    return username?.substring(0, 2).toUpperCase() || '??';
  };

  // Get avatar color
  const getAvatarColor = (username) => {
    const colors = [
      '#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A',
      '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E2'
    ];
    const index = username?.charCodeAt(0) % colors.length || 0;
    return colors[index];
  };

  // Handle right-click on message
  const handleContextMenu = (e, message) => {
    e.preventDefault();
    
    // Don't show menu for deleted messages
    if (message.isDeleted) return;
    
    const isOwnMessage = message.sender && message.sender._id === currentUserId;

    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      message: message,
      isOwn: isOwnMessage
    });
  };

  // Close context menu when clicking outside
  useEffect(() => {
    const handleClick = () => setContextMenu(null);
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  // Copy message
  const copyMessage = (text) => {
    if (!text) {
      alert('No text to copy');
      return;
    }
    
    navigator.clipboard.writeText(text)
      .then(() => {
        setContextMenu(null);
        alert('Message copied to clipboard!');
      })
      .catch((err) => {
        console.error('Failed to copy:', err);
        alert('Failed to copy message');
      });
  };

  // Edit message
  const startEditMessage = (message) => {
    setEditingMessageId(message._id);
    setEditText(message.content);
    setContextMenu(null);
  };

  const saveEditMessage = () => {
    if (!editText.trim()) {
      alert('Message cannot be empty');
      return;
    }
    
    console.log('Emitting editMessage:', {
      messageId: editingMessageId,
      newContent: editText.trim()
    });
    
    socket.emit('editMessage', {
      messageId: editingMessageId,
      newContent: editText.trim()
    });
    
    // Don't clear state here - wait for socket confirmation
    // State will be cleared in handleMessageEdited
  };

  const cancelEdit = () => {
    setEditingMessageId(null);
    setEditText('');
  };

  // Delete message
  const deleteMessage = (messageId) => {
    if (window.confirm('Are you sure you want to delete this message?')) {
      console.log('Emitting deleteMessage:', { messageId });
      
      socket.emit('deleteMessage', { messageId });
      setContextMenu(null);
      
      // Don't update state here - wait for socket confirmation
      // State will be updated in handleMessageDeleted
    }
  };

  // Filter messages by search query
  const filteredMessages = searchQuery.trim()
    ? messages.filter(msg => 
        msg.content?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        msg.sender?.username?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        msg.sender?.name?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : messages;

  // Render file attachment
  const renderFileAttachment = (message) => {
    if (message.messageType !== 'file' || !message.fileUrl) return null;

    const fileType = message.fileType || '';
    const fileUrl = message.fileUrl.startsWith('http') 
      ? message.fileUrl 
      : `${process.env.REACT_APP_API_URL || 'http://localhost:5000'}${message.fileUrl}`;

    // Image
    if (fileType.startsWith('image/')) {
      return (
        <img 
          src={fileUrl} 
          alt={message.fileName || 'Image'}
          style={styles.imageAttachment}
          onClick={() => window.open(fileUrl, '_blank')}
        />
      );
    }

    // Video
    if (fileType.startsWith('video/')) {
      return (
        <video 
          src={fileUrl} 
          controls 
          style={styles.videoAttachment}
        />
      );
    }

    // Document/PDF
    return (
      <a 
        href={fileUrl} 
        target="_blank" 
        rel="noopener noreferrer"
        style={styles.documentAttachment}
      >
        <span style={styles.documentIcon}>📄</span>
        <span>{message.fileName || 'Download File'}</span>
        <span style={styles.fileSize}>
          ({Math.round((message.fileSize || 0) / 1024)} KB)
        </span>
      </a>
    );
  };

  // Handle session action
  const handleSessionAction = () => {
    if (typeof onSessionEnded === 'function') {
      onSessionEnded(sessionInfo);
    } else {
      window.location.reload();
    }
  };

  return (
    <div style={styles.chatArea}>
      {/* Search Bar */}
      <div style={styles.searchBar}>
        <input
          type="text"
          placeholder="Search messages..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={styles.searchInput}
        />
        {searchQuery && (
          <button 
            onClick={() => setSearchQuery('')}
            style={styles.clearSearch}
          >
            ✕
          </button>
        )}
        {searchQuery && (
          <span style={styles.searchResults}>
            {filteredMessages.length} result{filteredMessages.length !== 1 ? 's' : ''}
          </span>
        )}
      </div>

      {/* Messages Container */}
      <div
        style={{
          ...styles.messagesContainer,
          pointerEvents: sessionActive ? 'auto' : 'none',
          opacity: sessionActive ? 1 : 0.55
        }}
        ref={messagesContainerRef}
        onScroll={handleScroll}
      >
        {/* Empty State */}
        {filteredMessages.length === 0 && !searchQuery && (
          <div style={styles.emptyState}>
            <div style={styles.emptyIcon}>💬</div>
            <p style={styles.emptyText}>No messages yet</p>
            <p style={styles.emptySubtext}>Start the conversation! 👋</p>
          </div>
        )}

        {/* No search results */}
        {filteredMessages.length === 0 && searchQuery && (
          <div style={styles.emptyState}>
            <div style={styles.emptyIcon}>🔍</div>
            <p style={styles.emptyText}>No messages found</p>
            <p style={styles.emptySubtext}>Try a different search term</p>
          </div>
        )}

        {/* Render Messages */}
        {filteredMessages.map((message, index) => {
          const isOwnMessage = message.sender && message.sender._id === currentUserId;
          const isSystemMessage = message.messageType === 'system';
          const showDateSeparator = needsDateSeparator(message, filteredMessages[index - 1]);
          const isEditing = editingMessageId === message._id;

          return (
            <React.Fragment key={message._id || `${index}-${message.createdAt}`}>
              {/* Date Separator */}
              {showDateSeparator && (
                <div style={styles.dateSeparator}>
                  <span style={styles.dateSeparatorText}>
                    {getDateSeparator(message.createdAt)}
                  </span>
                </div>
              )}

              {/* Message */}
              <div
                style={{
                  ...styles.messageWrapper,
                  justifyContent: isSystemMessage
                    ? 'center'
                    : isOwnMessage
                      ? 'flex-end'
                      : 'flex-start'
                }}
                onContextMenu={(e) => !isSystemMessage && handleContextMenu(e, message)}
              >
                {/* System Message */}
                {isSystemMessage ? (
                  <div style={styles.systemMessage}>
                    {message.content}
                  </div>
                ) : (
                  /* Regular Message */
                  <div style={styles.messageRow}>
                    {/* Avatar (for others' messages) */}
                    {!isOwnMessage && (
                      <div
                        style={{
                          ...styles.avatar,
                          backgroundColor: getAvatarColor(message.sender?.username)
                        }}
                      >
                        {getInitials(message.sender?.username)}
                      </div>
                    )}

                    {/* Message Bubble */}
                    <div style={{
                      ...styles.messageBubble,
                      backgroundColor: isOwnMessage 
                        ? (message.isDeleted ? '#999' : '#007bff') 
                        : (message.isDeleted ? '#e0e0e0' : 'white'),
                      color: isOwnMessage ? 'white' : '#333',
                      boxShadow: isOwnMessage
                        ? '0 2px 8px rgba(0,123,255,0.3)'
                        : '0 2px 8px rgba(0,0,0,0.1)',
                      animation: 'slideIn 0.3s ease-out',
                      opacity: message.isDeleted ? 0.7 : 1
                    }}>
                      {/* Sender Name */}
                      {!isOwnMessage && (
                        <div style={{
                          ...styles.senderName,
                          color: getAvatarColor(message.sender?.username)
                        }}>
                          {message.sender?.name || message.sender?.username}
                        </div>
                      )}

                      {/* Message Content or Edit Input */}
                      {isEditing ? (
                        <div style={styles.editContainer}>
                          <input
                            type="text"
                            value={editText}
                            onChange={(e) => setEditText(e.target.value)}
                            onKeyPress={(e) => {
                              if (e.key === 'Enter') saveEditMessage();
                              if (e.key === 'Escape') cancelEdit();
                            }}
                            style={styles.editInput}
                            autoFocus
                          />
                          <div style={styles.editButtons}>
                            <button onClick={saveEditMessage} style={styles.saveBtn}>Save</button>
                            <button onClick={cancelEdit} style={styles.cancelBtn}>Cancel</button>
                          </div>
                        </div>
                      ) : (
                        <>
                          {/* File Attachment */}
                          {message.messageType === 'file' && !message.isDeleted && renderFileAttachment(message)}
                          
                          {/* Text Content */}
                          {message.content && (
                            <div style={{
                              ...styles.messageContent,
                              fontStyle: message.isDeleted ? 'italic' : 'normal',
                              color: message.isDeleted 
                                ? (isOwnMessage ? 'rgba(255,255,255,0.8)' : '#666') 
                                : (isOwnMessage ? 'white' : '#333')
                            }}>
                              {message.content}
                            </div>
                          )}
                        </>
                      )}

                      {/* Footer: Time + Status */}
                      {!isEditing && (
                        <div style={styles.messageFooter}>
                          <span style={{
                            ...styles.timestamp,
                            color: isOwnMessage ? 'rgba(255,255,255,0.8)' : '#999'
                          }}>
                            {formatTime(message.createdAt)}
                          </span>

                          {/* Edited Label */}
                          {message.isEdited && !message.isDeleted && (
                            <span style={{
                              ...styles.editedLabel,
                              color: isOwnMessage ? 'rgba(255,255,255,0.7)' : '#999'
                            }}>
                              (edited)
                            </span>
                          )}

                          {/* Read Status */}
                          {isOwnMessage && (
                            <span style={styles.readStatus}>
                              ✓✓
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Avatar (for own messages) */}
                    {isOwnMessage && (
                      <div
                        style={{
                          ...styles.avatar,
                          backgroundColor: '#007bff'
                        }}
                      >
                        {getInitials(message.sender?.username)}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </React.Fragment>
          );
        })}

        {/* Typing Indicators - Only show if not empty and users exist */}
        {typingUsers && typingUsers.length > 0 && typingUsers.some(u => u && u.trim()) && (
          <div style={styles.typingWrapper}>
            <div style={styles.typingBubble}>
              <span style={styles.typingText}>
                {typingUsers.length === 1
                  ? `${typingUsers[0]} is typing`
                  : `${typingUsers.length} people are typing`}
              </span>
              <div style={styles.typingDots}>
                <span style={{ ...styles.dot, animationDelay: '0s' }}></span>
                <span style={{ ...styles.dot, animationDelay: '0.2s' }}></span>
                <span style={{ ...styles.dot, animationDelay: '0.4s' }}></span>
              </div>
            </div>
          </div>
        )}

        {/* Auto-scroll anchor */}
        <div ref={messagesEndRef} />
      </div>

      {/* Scroll to Bottom Button */}
      {showScrollButton && (
        <button
          style={styles.scrollButton}
          onClick={() => scrollToBottom()}
        >
          ↓
        </button>
      )}

      {/* Context Menu */}
      {contextMenu && (
        <div
          style={{
            ...styles.contextMenu,
            top: contextMenu.y,
            left: contextMenu.x
          }}
        >
          <div
            style={styles.contextMenuItem}
            onClick={() => copyMessage(contextMenu.message.content)}
          >
            📋 Copy
          </div>
          {contextMenu.isOwn && !contextMenu.message.isDeleted && (
            <>
              <div 
                style={styles.contextMenuItem}
                onClick={() => startEditMessage(contextMenu.message)}
              >
                ✏️ Edit
              </div>
              <div 
                style={{ ...styles.contextMenuItem, color: '#dc3545' }}
                onClick={() => deleteMessage(contextMenu.message._id)}
              >
                🗑️ Delete
              </div>
            </>
          )}
        </div>
      )}

      {/* Session Ended Overlay */}
      {!sessionActive && (
        <div style={styles.sessionOverlay}>
          <div style={styles.sessionBox}>
            <h3 style={{ margin: 0 }}>Session Ended</h3>
            <p style={{ marginTop: 8 }}>
              {sessionInfo?.message || 'This session has been ended by the teacher.'}
            </p>
            <div style={{ marginTop: 12, display: 'flex', gap: 8, justifyContent: 'center' }}>
              <button
                onClick={handleSessionAction}
                style={styles.sessionBtnPrimary}
              >
                Back to Home
              </button>
              <button
                onClick={() => setSessionActive(true)}
                style={styles.sessionBtnSecondary}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// STYLES
const styles = {
  chatArea: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    backgroundColor: '#f0f2f5',
    position: 'relative'
  },
  searchBar: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    padding: '10px 20px',
    backgroundColor: 'white',
    borderBottom: '1px solid #e0e0e0'
  },
  searchInput: {
    flex: 1,
    padding: '8px 12px',
    fontSize: '14px',
    border: '1px solid #ddd',
    borderRadius: '20px',
    outline: 'none'
  },
  clearSearch: {
    background: 'none',
    border: 'none',
    fontSize: '18px',
    cursor: 'pointer',
    color: '#666'
  },
  searchResults: {
    fontSize: '12px',
    color: '#666',
    whiteSpace: 'nowrap'
  },
  messagesContainer: {
    flex: 1,
    overflowY: 'auto',
    padding: '20px',
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  emptyState: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
    color: '#999'
  },
  emptyIcon: {
    fontSize: '64px',
    marginBottom: '16px',
    opacity: 0.5
  },
  emptyText: {
    fontSize: '18px',
    fontWeight: '600',
    margin: '0 0 8px 0'
  },
  emptySubtext: {
    fontSize: '14px',
    margin: 0
  },
  dateSeparator: {
    display: 'flex',
    justifyContent: 'center',
    margin: '20px 0',
    position: 'relative'
  },
  dateSeparatorText: {
    backgroundColor: '#e0e0e0',
    color: '#666',
    padding: '4px 12px',
    borderRadius: '12px',
    fontSize: '12px',
    fontWeight: '500'
  },
  messageWrapper: {
    display: 'flex',
    width: '100%',
    marginBottom: '4px'
  },
  systemMessage: {
    padding: '8px 16px',
    backgroundColor: '#e9ecef',
    color: '#666',
    borderRadius: '15px',
    fontSize: '13px',
    fontStyle: 'italic',
    textAlign: 'center',
    maxWidth: '70%'
  },
  messageRow: {
    display: 'flex',
    gap: '8px',
    alignItems: 'flex-end',
    maxWidth: '75%'
  },
  avatar: {
    width: '32px',
    height: '32px',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'white',
    fontSize: '12px',
    fontWeight: '600',
    flexShrink: 0
  },
  messageBubble: {
    padding: '10px 14px',
    borderRadius: '18px',
    wordWrap: 'break-word',
    minWidth: '60px',
    maxWidth: '100%'
  },
  senderName: {
    fontSize: '12px',
    fontWeight: '600',
    marginBottom: '4px',
    opacity: 0.9
  },
  messageContent: {
    fontSize: '15px',
    lineHeight: '1.4',
    marginBottom: '4px',
    wordBreak: 'break-word'
  },
  imageAttachment: {
    maxWidth: '100%',
    maxHeight: '300px',
    borderRadius: '8px',
    cursor: 'pointer',
    marginBottom: '4px'
  },
  videoAttachment: {
    maxWidth: '100%',
    maxHeight: '300px',
    borderRadius: '8px',
    marginBottom: '4px'
  },
  documentAttachment: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    padding: '8px 12px',
    backgroundColor: 'rgba(0,0,0,0.05)',
    borderRadius: '8px',
    textDecoration: 'none',
    color: 'inherit',
    marginBottom: '4px'
  },
  documentIcon: {
    fontSize: '20px'
  },
  fileSize: {
    fontSize: '11px',
    opacity: 0.7
  },
  editContainer: {
    width: '100%'
  },
  editInput: {
    width: '100%',
    padding: '8px',
    fontSize: '14px',
    border: '1px solid #ddd',
    borderRadius: '6px',
    marginBottom: '8px'
  },
  editButtons: {
    display: 'flex',
    gap: '8px'
  },
  saveBtn: {
    padding: '4px 12px',
    fontSize: '12px',
    backgroundColor: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer'
  },
  cancelBtn: {
    padding: '4px 12px',
    fontSize: '12px',
    backgroundColor: '#6c757d',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer'
  },
  messageFooter: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    marginTop: '2px'
  },
  timestamp: {
    fontSize: '11px'
  },
  editedLabel: {
    fontSize: '11px',
    fontStyle: 'italic'
  },
  readStatus: {
    fontSize: '11px',
    marginLeft: '4px'
  },
  typingWrapper: {
    display: 'flex',
    justifyContent: 'flex-start',
    marginTop: '8px'
  },
  typingBubble: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    padding: '10px 14px',
    backgroundColor: 'white',
    borderRadius: '18px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
  },
  typingText: {
    fontSize: '13px',
    color: '#666',
    fontStyle: 'italic'
  },
  typingDots: {
    display: 'flex',
    gap: '4px',
    alignItems: 'center'
  },
  dot: {
    width: '6px',
    height: '6px',
    backgroundColor: '#999',
    borderRadius: '50%',
    animation: 'bounce 1.4s infinite ease-in-out both'
  },
  scrollButton: {
    position: 'absolute',
    bottom: '20px',
    right: '20px',
    width: '40px',
    height: '40px',
    borderRadius: '50%',
    backgroundColor: '#007bff',
    color: 'white',
    border: 'none',
    fontSize: '20px',
    cursor: 'pointer',
    boxShadow: '0 4px 12px rgba(0,123,255,0.4)',
    transition: 'all 0.3s',
    zIndex: 10
  },
  contextMenu: {
    position: 'fixed',
    backgroundColor: 'white',
    borderRadius: '8px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
    padding: '8px 0',
    zIndex: 1000,
    minWidth: '150px'
  },
  contextMenuItem: {
    padding: '10px 16px',
    fontSize: '14px',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
    borderBottom: '1px solid #f0f0f0'
  },
  sessionOverlay: {
    position: 'absolute',
    inset: 0,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(10,10,10,0.45)',
    zIndex: 2000
  },
  sessionBox: {
    background: 'white',
    padding: '20px',
    borderRadius: '12px',
    boxShadow: '0 8px 30px rgba(0,0,0,0.25)',
    maxWidth: '420px',
    textAlign: 'center'
  },
  sessionBtnPrimary: {
    background: '#007bff',
    color: 'white',
    border: 'none',
    padding: '8px 16px',
    borderRadius: '8px',
    cursor: 'pointer',
    fontWeight: 600
  },
  sessionBtnSecondary: {
    background: '#eee',
    color: '#333',
    border: 'none',
    padding: '8px 16px',
    borderRadius: '8px',
    cursor: 'pointer',
    fontWeight: 600
  }
};

// Add hover effects
if (typeof document !== 'undefined') {
  const style = document.createElement('style');
  style.textContent = `
    div[style*="contextMenuItem"]:hover {
      background-color: #f0f0f0 !important;
    }
    button[style*="scrollButton"]:hover {
      transform: scale(1.1);
    }
    button[style*="saveBtn"]:hover {
      background-color: #218838 !important;
    }
    button[style*="cancelBtn"]:hover {
      background-color: #5a6268 !important;
    }
  `;
  document.head.appendChild(style);
}

export default ChatArea;