// src/components/PollComponent.js
import React, { useState, useEffect } from 'react';
import socket from '../socket';

const PollComponent = ({ groupId, currentUserId, isAdmin }) => {
  const [polls, setPolls] = useState([]);
  const [showCreatePoll, setShowCreatePoll] = useState(false);
  const [pollType, setPollType] = useState('mcq');
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '', '', '']);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState('');

  // ============================================
  // LOAD POLLS
  // ============================================
  useEffect(() => {
    if (!groupId) return;

    // Request polls from server
    socket.emit('getPolls', { groupId });

    // Listen for poll updates
    socket.on('pollsUpdate', (data) => {
      setPolls(data.polls || []);
    });

    socket.on('newPoll', (poll) => {
      setPolls(prev => [poll, ...prev]);
    });

    socket.on('pollUpdated', (updatedPoll) => {
      setPolls(prev => prev.map(p => 
        p._id === updatedPoll._id ? updatedPoll : p
      ));
    });

    return () => {
      socket.off('pollsUpdate');
      socket.off('newPoll');
      socket.off('pollUpdated');
    };
  }, [groupId]);

  // ============================================
  // CREATE POLL
  // ============================================
  const handleCreatePoll = () => {
    setError('');

    if (!question.trim()) {
      setError('Question is required');
      return;
    }

    if (pollType === 'mcq' || pollType === 'yesno') {
      const validOptions = options.filter(opt => opt.trim());
      if (validOptions.length < 2) {
        setError('At least 2 options required for MCQ polls');
        return;
      }
    }

    setCreating(true);

    const pollData = {
      groupId,
      pollType,
      question: question.trim(),
      options: pollType === 'yesno' 
        ? [{ text: 'Yes' }, { text: 'No' }]
        : pollType === 'mcq'
          ? options.filter(opt => opt.trim()).map(text => ({ text: text.trim() }))
          : []
    };

    socket.emit('createPoll', pollData);

    // Reset form
    setTimeout(() => {
      setQuestion('');
      setOptions(['', '', '', '']);
      setPollType('mcq');
      setShowCreatePoll(false);
      setCreating(false);
    }, 500);
  };

  // ============================================
  // VOTE ON POLL
  // ============================================
  const handleVote = (pollId, optionIndex) => {
    socket.emit('votePoll', {
      pollId,
      optionIndex
    });
  };

  // ============================================
  // SUBMIT ANSWER (Open Question)
  // ============================================
  const handleSubmitAnswer = (pollId, answer) => {
    if (!answer.trim()) {
      alert('Please enter an answer');
      return;
    }

    socket.emit('answerPoll', {
      pollId,
      answer: answer.trim()
    });
  };

  // ============================================
  // CLOSE POLL (Admin only)
  // ============================================
  const handleClosePoll = (pollId) => {
    if (window.confirm('Close this poll? No more votes/answers will be accepted.')) {
      socket.emit('closePoll', { pollId });
    }
  };

  // ============================================
  // RENDER POLL RESULTS
  // ============================================
  const renderPollResults = (poll) => {
    const totalVotes = poll.totalVotes || 0;

    return (
      <div style={styles.resultsContainer}>
        {poll.options.map((option, index) => {
          const percentage = totalVotes > 0 
            ? ((option.votes || 0) / totalVotes * 100).toFixed(1) 
            : 0;

          return (
            <div key={index} style={styles.resultItem}>
              <div style={styles.resultHeader}>
                <span style={styles.optionText}>{option.text}</span>
                <span style={styles.voteCount}>
                  {option.votes || 0} vote{(option.votes || 0) !== 1 ? 's' : ''} ({percentage}%)
                </span>
              </div>
              <div style={styles.progressBar}>
                <div 
                  style={{
                    ...styles.progressFill,
                    width: `${percentage}%`
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  // ============================================
  // RENDER OPEN QUESTION ANSWERS
  // ============================================
  const renderOpenAnswers = (poll) => {
    if (!poll.answers || poll.answers.length === 0) {
      return <p style={styles.noAnswers}>No answers yet</p>;
    }

    return (
      <div style={styles.answersContainer}>
        <p style={styles.answerCount}>
          {poll.answers.length} answer{poll.answers.length !== 1 ? 's' : ''}:
        </p>
        {poll.answers.map((ans, index) => (
          <div key={index} style={styles.answerItem}>
            <div style={styles.answerHeader}>
              <strong>{ans.user?.username || ans.user?.name || 'Student'}</strong>
              <span style={styles.answerTime}>
                {new Date(ans.submittedAt).toLocaleTimeString()}
              </span>
            </div>
            <p style={styles.answerText}>{ans.answer}</p>
          </div>
        ))}
      </div>
    );
  };

  // ============================================
  // RENDER SINGLE POLL
  // ============================================
  const renderPoll = (poll) => {
    const hasVoted = poll.options?.some(opt => 
      opt.votedBy?.some(voterId => 
        String(voterId._id || voterId) === String(currentUserId)
      )
    );

    const hasAnswered = poll.answers?.some(ans => 
      String(ans.user?._id || ans.user) === String(currentUserId)
    );

    const [answerText, setAnswerText] = userState('');

    return (
      <div key={poll._id} style={styles.pollCard}>
        {/* Poll Header */}
        <div style={styles.pollHeader}>
          <div>
            <span style={styles.pollType}>
              {poll.pollType === 'mcq' ? '📊 MCQ' : poll.pollType === 'yesno' ? '✓ Yes/No' : '📝 Open'}
            </span>
            {!poll.isActive && <span style={styles.closedBadge}>Closed</span>}
          </div>
          {isAdmin && poll.isActive && (
            <button 
              style={styles.closeBtn}
              onClick={() => handleClosePoll(poll._id)}
            >
              Close Poll
            </button>
          )}
        </div>

        {/* Question */}
        <h3 style={styles.pollQuestion}>{poll.question}</h3>

        {/* MCQ / Yes-No Poll */}
        {(poll.pollType === 'mcq' || poll.pollType === 'yesno') && (
          <>
            {!hasVoted && poll.isActive ? (
              // Voting interface
              <div style={styles.optionsContainer}>
                {poll.options.map((option, index) => (
                  <button
                    key={index}
                    style={styles.optionButton}
                    onClick={() => handleVote(poll._id, index)}
                  >
                    {option.text}
                  </button>
                ))}
              </div>
            ) : (
              // Results
              <>
                {hasVoted && poll.isActive && (
                  <p style={styles.votedMessage}>✓ You voted on this poll</p>
                )}
                {renderPollResults(poll)}
              </>
            )}
          </>
        )}

        {/* Open Question */}
        {poll.pollType === 'open' && (
          <>
            {!hasAnswered && poll.isActive ? (
              // Answer interface
              <div style={styles.answerForm}>
                <textarea
                  value={answerText}
                  onChange={(e) => setAnswerText(e.target.value)}
                  placeholder="Type your answer..."
                  style={styles.answerInput}
                  rows={3}
                />
                <button
                  style={styles.submitBtn}
                  onClick={() => {
                    handleSubmitAnswer(poll._id, answerText);
                    setAnswerText('');
                  }}
                >
                  Submit Answer
                </button>
              </div>
            ) : (
              // Show answers
              <>
                {hasAnswered && poll.isActive && (
                  <p style={styles.votedMessage}>✓ You answered this question</p>
                )}
                {renderOpenAnswers(poll)}
              </>
            )}
          </>
        )}

        {/* Poll Footer */}
        <div style={styles.pollFooter}>
          <span style={styles.pollTime}>
            Created {new Date(poll.createdAt).toLocaleString()}
          </span>
          <span style={styles.pollCreator}>
            by {poll.createdBy?.name || poll.createdBy?.username || 'Teacher'}
          </span>
        </div>
      </div>
    );
  };

  // ============================================
  // RENDER
  // ============================================
  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <h2 style={styles.title}>Polls & Questions</h2>
        {isAdmin && (
          <button
            style={styles.createBtn}
            onClick={() => setShowCreatePoll(!showCreatePoll)}
          >
            {showCreatePoll ? 'Cancel' : '+ Create Poll'}
          </button>
        )}
      </div>

      {/* Create Poll Form (Admin only) */}
      {isAdmin && showCreatePoll && (
        <div style={styles.createForm}>
          <h3 style={styles.formTitle}>Create New Poll</h3>

          {/* Poll Type */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Poll Type:</label>
            <select 
              value={pollType} 
              onChange={(e) => setPollType(e.target.value)}
              style={styles.select}
            >
              <option value="mcq">Multiple Choice</option>
              <option value="yesno">Yes/No</option>
              <option value="open">Open Question</option>
            </select>
          </div>

          {/* Question */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Question:</label>
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Enter your question..."
              style={styles.input}
            />
          </div>

          {/* Options (for MCQ) */}
          {pollType === 'mcq' && (
            <div style={styles.formGroup}>
              <label style={styles.label}>Options:</label>
              {options.map((option, index) => (
                <input
                  key={index}
                  type="text"
                  value={option}
                  onChange={(e) => {
                    const newOptions = [...options];
                    newOptions[index] = e.target.value;
                    setOptions(newOptions);
                  }}
                  placeholder={`Option ${index + 1}`}
                  style={styles.optionInput}
                />
              ))}
              <button
                style={styles.addOptionBtn}
                onClick={() => setOptions([...options, ''])}
              >
                + Add Option
              </button>
            </div>
          )}

          {/* Error */}
          {error && <div style={styles.error}>{error}</div>}

          {/* Submit */}
          <button
            style={styles.submitBtn}
            onClick={handleCreatePoll}
            disabled={creating}
          >
            {creating ? 'Creating...' : 'Create Poll'}
          </button>
        </div>
      )}

      {/* Polls List */}
      <div style={styles.pollsList}>
        {polls.length === 0 ? (
          <div style={styles.emptyState}>
            <p style={styles.emptyIcon}>📊</p>
            <p style={styles.emptyText}>No polls yet</p>
            {isAdmin && (
              <p style={styles.emptySubtext}>Create a poll to engage your students!</p>
            )}
          </div>
        ) : (
          polls.map(poll => renderPoll(poll))
        )}
      </div>
    </div>
  );
};

// ============================================
// STYLES
// ============================================
const styles = {
  container: {
    padding: '20px',
    maxWidth: '800px',
    margin: '0 auto'
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px'
  },
  title: {
    fontSize: '24px',
    fontWeight: '700',
    color: '#333',
    margin: 0
  },
  createBtn: {
    padding: '10px 20px',
    fontSize: '14px',
    fontWeight: '600',
    backgroundColor: '#007bff',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer'
  },
  
  // Create Form
  createForm: {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '10px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    marginBottom: '20px'
  },
  formTitle: {
    fontSize: '18px',
    fontWeight: '600',
    color: '#333',
    marginBottom: '15px'
  },
  formGroup: {
    marginBottom: '15px'
  },
  label: {
    display: 'block',
    fontSize: '14px',
    fontWeight: '600',
    color: '#333',
    marginBottom: '5px'
  },
  select: {
    width: '100%',
    padding: '10px',
    fontSize: '14px',
    border: '1px solid #ddd',
    borderRadius: '6px',
    outline: 'none'
  },
  input: {
    width: '100%',
    padding: '10px',
    fontSize: '14px',
    border: '1px solid #ddd',
    borderRadius: '6px',
    outline: 'none'
  },
  optionInput: {
    width: '100%',
    padding: '8px',
    fontSize: '14px',
    border: '1px solid #ddd',
    borderRadius: '6px',
    marginBottom: '8px',
    outline: 'none'
  },
  addOptionBtn: {
    padding: '6px 12px',
    fontSize: '13px',
    backgroundColor: '#f8f9fa',
    color: '#007bff',
    border: '1px solid #ddd',
    borderRadius: '6px',
    cursor: 'pointer'
  },
  error: {
    padding: '10px',
    backgroundColor: '#fee',
    color: '#dc3545',
    borderRadius: '6px',
    fontSize: '13px',
    marginBottom: '10px'
  },
  submitBtn: {
    width: '100%',
    padding: '12px',
    fontSize: '15px',
    fontWeight: '600',
    backgroundColor: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer'
  },
  
  // Polls List
  pollsList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px'
  },
  emptyState: {
    textAlign: 'center',
    padding: '60px 20px',
    color: '#999'
  },
  emptyIcon: {
    fontSize: '48px',
    margin: '0 0 10px 0'
  },
  emptyText: {
    fontSize: '18px',
    fontWeight: '600',
    margin: '0 0 5px 0'
  },
  emptySubtext: {
    fontSize: '14px',
    margin: 0
  },
  
  // Poll Card
  pollCard: {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '10px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
  },
  pollHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '15px'
  },
  pollType: {
    fontSize: '13px',
    fontWeight: '600',
    color: '#007bff',
    backgroundColor: '#e3f2fd',
    padding: '4px 10px',
    borderRadius: '12px',
    marginRight: '8px'
  },
  closedBadge: {
    fontSize: '11px',
    fontWeight: '600',
    color: '#dc3545',
    backgroundColor: '#fee',
    padding: '3px 8px',
    borderRadius: '12px'
  },
  closeBtn: {
    padding: '6px 12px',
    fontSize: '12px',
    backgroundColor: '#dc3545',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer'
  },
  pollQuestion: {
    fontSize: '18px',
    fontWeight: '600',
    color: '#333',
    marginBottom: '15px'
  },
  
  // Options
  optionsContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    marginBottom: '15px'
  },
  optionButton: {
    padding: '12px',
    fontSize: '15px',
    backgroundColor: 'white',
    color: '#333',
    border: '2px solid #007bff',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'all 0.2s',
    textAlign: 'left'
  },
  votedMessage: {
    fontSize: '13px',
    color: '#28a745',
    backgroundColor: '#d4edda',
    padding: '8px 12px',
    borderRadius: '6px',
    marginBottom: '15px'
  },
  
  // Results
  resultsContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: '12px',
    marginBottom: '15px'
  },
  resultItem: {
    marginBottom: '8px'
  },
  resultHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '6px'
  },
  optionText: {
    fontSize: '14px',
    color: '#333',
    fontWeight: '500'
  },
  voteCount: {
    fontSize: '12px',
    color: '#666'
  },
  progressBar: {
    height: '8px',
    backgroundColor: '#e9ecef',
    borderRadius: '4px',
    overflow: 'hidden'
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#007bff',
    transition: 'width 0.3s'
  },
  
  // Open Question
  answerForm: {
    marginBottom: '15px'
  },
  answerInput: {
    width: '100%',
    padding: '10px',
    fontSize: '14px',
    border: '1px solid #ddd',
    borderRadius: '6px',
    resize: 'vertical',
    outline: 'none',
    marginBottom: '10px'
  },
  answersContainer: {
    marginBottom: '15px'
  },
  answerCount: {
    fontSize: '13px',
    fontWeight: '600',
    color: '#666',
    marginBottom: '10px'
  },
  answerItem: {
    padding: '12px',
    backgroundColor: '#f8f9fa',
    borderRadius: '6px',
    marginBottom: '8px'
  },
  answerHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '6px'
  },
  answerTime: {
    fontSize: '11px',
    color: '#999'
  },
  answerText: {
    fontSize: '14px',
    color: '#333',
    margin: 0
  },
  noAnswers: {
    fontSize: '14px',
    color: '#999',
    textAlign: 'center',
    padding: '20px'
  },
  
  // Footer
  pollFooter: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: '15px',
    borderTop: '1px solid #e9ecef',
    fontSize: '12px',
    color: '#999'
  },
  pollTime: {},
  pollCreator: {
    fontStyle: 'italic'
  }
};

// Add hover effects
if (typeof document !== 'undefined') {
  const style = document.createElement('style');
  style.textContent = `
    button[style*="optionButton"]:hover {
      background-color: #007bff !important;
      color: white !important;
    }
  `;
  document.head.appendChild(style);
}

export default PollComponent;