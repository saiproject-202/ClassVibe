// src/components/MessageInput.js
import React, { useState, useRef, useEffect } from 'react';
import { uploadFile } from '../api';

const MessageInput = ({ 
  onSendMessage, 
  onTyping, 
  onStopTyping, 
  disabled = false,
  isAdmin = false,
  members = []
}) => {
  
  // ============================================
  // STATE MANAGEMENT
  // ============================================
  const [message, setMessage] = useState('');
  const [showFileMenu, setShowFileMenu] = useState(false);
  const [showRecipients, setShowRecipients] = useState(false);
  const [selectedRecipient, setSelectedRecipient] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  
  const typingTimeoutRef = useRef(null);
  const inputRef = useRef(null);
  const fileInputRef = useRef(null);
  
  // ============================================
  // HANDLE INPUT CHANGE
  // ============================================
  const handleInputChange = (e) => {
    const value = e.target.value;
    setMessage(value);
    
    // Trigger typing indicator
    if (value.trim() && onTyping) {
      onTyping();
      
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      
      typingTimeoutRef.current = setTimeout(() => {
        if (onStopTyping) {
          onStopTyping();
        }
      }, 2000);
    }
  };
  
  // ============================================
  // SEND MESSAGE
  // ============================================
  const handleSendMessage = (e) => {
    e.preventDefault();
    
    if (!message.trim()) return;
    
    const messageData = {
      content: message.trim(),
      messageType: selectedRecipient ? 'private' : 'text',
      recipientId: selectedRecipient ? selectedRecipient._id : null
    };
    
    if (onSendMessage) {
      onSendMessage(messageData);
    }
    
    setMessage('');
    setSelectedRecipient(null);
    
    if (onStopTyping) {
      onStopTyping();
    }
    
    inputRef.current?.focus();
  };
  
  // ============================================
  // FILE UPLOAD HANDLING
  // ============================================
  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Validate file size (10MB max)
    if (file.size > 10 * 1024 * 1024) {
      alert('File too large! Maximum size is 10MB');
      return;
    }
    
    // Validate file type
    const allowedTypes = /\.(jpg|jpeg|png|gif|mp4|mov|pdf|doc|docx|txt)$/i;
    if (!allowedTypes.test(file.name)) {
      alert('Invalid file type! Allowed: Images, Videos, PDFs, Documents');
      return;
    }
    
    setUploading(true);
    setUploadProgress(0);
    
    try {
      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 200);
      
      // Upload file
      const response = await uploadFile(file);
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      if (response.success) {
        // Send file as message
        const fileMessage = {
          content: file.name,
          messageType: 'file',
          fileUrl: response.file.url,
          fileName: response.file.name,
          fileSize: response.file.size,
          fileType: response.file.type,
          recipientId: selectedRecipient ? selectedRecipient._id : null
        };
        
        if (onSendMessage) {
          onSendMessage(fileMessage);
        }
        
        setSelectedRecipient(null);
      }
    } catch (error) {
      console.error('Upload failed:', error);
      alert('Failed to upload file. Please try again.');
    } finally {
      setUploading(false);
      setUploadProgress(0);
      setShowFileMenu(false);
      
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };
  
  const handleFileMenuClick = (type) => {
    setShowFileMenu(false);
    
    if (type === 'camera') {
      // Open camera (mobile only)
      if (fileInputRef.current) {
        fileInputRef.current.setAttribute('capture', 'environment');
        fileInputRef.current.setAttribute('accept', 'image/*,video/*');
        fileInputRef.current.click();
      }
    } else if (type === 'gallery') {
      // Open gallery
      if (fileInputRef.current) {
        fileInputRef.current.removeAttribute('capture');
        fileInputRef.current.setAttribute('accept', 'image/*,video/*');
        fileInputRef.current.click();
      }
    } else if (type === 'document') {
      // Open file picker for documents
      if (fileInputRef.current) {
        fileInputRef.current.removeAttribute('capture');
        fileInputRef.current.setAttribute('accept', '.pdf,.doc,.docx,.txt');
        fileInputRef.current.click();
      }
    }
  };
  
  // ============================================
  // RECIPIENT SELECTION (Admin only)
  // ============================================
  const handleRecipientSelect = (member) => {
    if (selectedRecipient && selectedRecipient._id === member._id) {
      setSelectedRecipient(null);
    } else {
      setSelectedRecipient(member);
    }
    
    setShowRecipients(false);
    inputRef.current?.focus();
  };
  
  // ============================================
  // CLEANUP
  // ============================================
  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    };
  }, []);
  
  // ============================================
  // RENDER
  // ============================================
  return (
    <div style={styles.container}>
      
      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        style={{ display: 'none' }}
        onChange={handleFileSelect}
      />
      
      {/* Upload Progress */}
      {uploading && (
        <div style={styles.uploadProgress}>
          <div style={styles.progressBar}>
            <div 
              style={{
                ...styles.progressFill,
                width: `${uploadProgress}%`
              }}
            />
          </div>
          <span style={styles.progressText}>Uploading... {uploadProgress}%</span>
        </div>
      )}
      
      {/* Selected Recipient Banner */}
      {selectedRecipient && (
        <div style={styles.recipientBanner}>
          <span style={styles.recipientText}>
            Private message to: <strong>{selectedRecipient.username}</strong>
          </span>
          <button
            onClick={() => setSelectedRecipient(null)}
            style={styles.clearRecipient}
          >
            ✕
          </button>
        </div>
      )}
      
      {/* File Menu Popup */}
      {showFileMenu && (
        <div style={styles.fileMenu}>
          <button
            onClick={() => handleFileMenuClick('camera')}
            style={styles.fileMenuItem}
          >
            📷 Camera
          </button>
          <button
            onClick={() => handleFileMenuClick('gallery')}
            style={styles.fileMenuItem}
          >
            🖼️ Gallery
          </button>
          <button
            onClick={() => handleFileMenuClick('document')}
            style={styles.fileMenuItem}
          >
            📄 Document
          </button>
        </div>
      )}
      
      {/* Recipient Dropdown */}
      {showRecipients && isAdmin && (
        <div style={styles.recipientDropdown}>
          <div style={styles.recipientHeader}>Send to:</div>
          <button
            onClick={() => {
              setSelectedRecipient(null);
              setShowRecipients(false);
            }}
            style={{
              ...styles.recipientOption,
              backgroundColor: !selectedRecipient ? '#e3f2fd' : 'transparent'
            }}
          >
            📢 Everyone
          </button>
          {members.map((member) => (
            <button
              key={member._id}
              onClick={() => handleRecipientSelect(member)}
              style={{
                ...styles.recipientOption,
                backgroundColor: 
                  selectedRecipient && selectedRecipient._id === member._id 
                    ? '#e3f2fd' 
                    : 'transparent'
              }}
            >
              👤 {member.username}
            </button>
          ))}
        </div>
      )}
      
      {/* Input Form */}
      <form onSubmit={handleSendMessage} style={styles.inputForm}>
        
        {/* + Button (File Upload) */}
        <button
          type="button"
          onClick={() => setShowFileMenu(!showFileMenu)}
          style={styles.iconButton}
          disabled={disabled || uploading}
          title="Attach file"
        >
          +
        </button>
        
        {/* Recipient Button (Admin only) */}
        {isAdmin && (
          <button
            type="button"
            onClick={() => setShowRecipients(!showRecipients)}
            style={styles.iconButton}
            disabled={disabled || uploading}
            title="Select recipient"
          >
            👥
          </button>
        )}
        
        {/* Text Input */}
        <input
          ref={inputRef}
          type="text"
          value={message}
          onChange={handleInputChange}
          placeholder={
            uploading 
              ? "Uploading..." 
              : selectedRecipient 
                ? `Private message to ${selectedRecipient.username}...`
                : "Type a message..."
          }
          style={styles.input}
          disabled={disabled || uploading}
          maxLength={5000}
        />
        
        {/* Send Button */}
        <button
          type="submit"
          style={{
            ...styles.sendButton,
            opacity: !message.trim() || disabled || uploading ? 0.5 : 1,
            cursor: !message.trim() || disabled || uploading ? 'not-allowed' : 'pointer'
          }}
          disabled={!message.trim() || disabled || uploading}
        >
          ➤
        </button>
      </form>
    </div>
  );
};

// ============================================
// STYLES
// ============================================
const styles = {
  container: {
    position: 'relative',
    borderTop: '1px solid #e0e0e0',
    backgroundColor: 'white',
    padding: '15px',
    boxShadow: '0 -2px 5px rgba(0,0,0,0.05)'
  },
  uploadProgress: {
    marginBottom: '10px'
  },
  progressBar: {
    width: '100%',
    height: '4px',
    backgroundColor: '#e0e0e0',
    borderRadius: '2px',
    overflow: 'hidden',
    marginBottom: '5px'
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#007bff',
    transition: 'width 0.3s'
  },
  progressText: {
    fontSize: '12px',
    color: '#666'
  },
  recipientBanner: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '8px 12px',
    backgroundColor: '#e3f2fd',
    borderRadius: '6px',
    marginBottom: '10px'
  },
  recipientText: {
    fontSize: '13px',
    color: '#1976d2'
  },
  clearRecipient: {
    background: 'none',
    border: 'none',
    fontSize: '16px',
    cursor: 'pointer',
    color: '#666',
    padding: '0 5px'
  },
  fileMenu: {
    position: 'absolute',
    bottom: '70px',
    left: '15px',
    backgroundColor: 'white',
    border: '1px solid #ddd',
    borderRadius: '10px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
    overflow: 'hidden',
    zIndex: 100
  },
  fileMenuItem: {
    width: '100%',
    padding: '12px 20px',
    fontSize: '15px',
    textAlign: 'left',
    border: 'none',
    backgroundColor: 'white',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
    display: 'flex',
    alignItems: 'center',
    gap: '10px'
  },
  recipientDropdown: {
    position: 'absolute',
    bottom: '70px',
    right: '15px',
    backgroundColor: 'white',
    border: '1px solid #ddd',
    borderRadius: '8px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
    minWidth: '200px',
    maxHeight: '300px',
    overflowY: 'auto',
    zIndex: 100
  },
  recipientHeader: {
    padding: '10px 15px',
    fontSize: '13px',
    fontWeight: '600',
    color: '#666',
    borderBottom: '1px solid #e0e0e0'
  },
  recipientOption: {
    width: '100%',
    padding: '10px 15px',
    fontSize: '14px',
    textAlign: 'left',
    border: 'none',
    cursor: 'pointer',
    transition: 'background-color 0.2s'
  },
  inputForm: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px'
  },
  iconButton: {
    fontSize: '28px',
    fontWeight: '300',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    padding: '8px 12px',
    borderRadius: '50%',
    transition: 'background-color 0.2s',
    flexShrink: 0,
    color: '#666'
  },
  input: {
    flex: 1,
    padding: '12px 15px',
    fontSize: '15px',
    border: '1px solid #ddd',
    borderRadius: '25px',
    outline: 'none',
    transition: 'border-color 0.3s'
  },
  sendButton: {
    width: '45px',
    height: '45px',
    fontSize: '20px',
    backgroundColor: '#007bff',
    color: 'white',
    border: 'none',
    borderRadius: '50%',
    cursor: 'pointer',
    transition: 'all 0.3s',
    flexShrink: 0,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  }
};

// Add hover effects via CSS-in-JS (inline doesn't support :hover)
if (typeof document !== 'undefined') {
  const style = document.createElement('style');
  style.textContent = `
    button[style*="fileMenuItem"]:hover {
      background-color: #f0f0f0 !important;
    }
    button[style*="iconButton"]:hover {
      background-color: #f0f0f0 !important;
    }
    button[style*="recipientOption"]:hover {
      background-color: #f5f5f5 !important;
    }
  `;
  document.head.appendChild(style);
}

export default MessageInput;