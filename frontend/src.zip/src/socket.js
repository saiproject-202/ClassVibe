// src/socket.js
// Socket wrapper that reads socket host from env. Keeps autoConnect:false so your app can
// set token/auth before calling socket.connect().
import { io } from "socket.io-client";

const RAW_SOCKET =
  process.env.REACT_APP_SOCKET_URL ||
  process.env.VITE_SOCKET_URL ||
  process.env.SOCKET_URL ||
  process.env.REACT_APP_API_URL ||
  process.env.VITE_API_URL ||
  "http://localhost:5000";

// If the provided URL contains /api, strip it (common if you reuse API_BASE)
const SOCKET_BASE = RAW_SOCKET.replace(/\/api\/?$/, "").replace(/\/$/, "");

export const SOCKET_URL = SOCKET_BASE;

const socket = io(SOCKET_URL, {
  autoConnect: false, // call socket.connect() after you set auth or localStorage token
  reconnection: true,
  reconnectionDelay: 1000,
  reconnectionAttempts: 10,
  transports: ["websocket", "polling"],
});

export default socket;
