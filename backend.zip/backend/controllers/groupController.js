// backend/controllers/groupController.js
const crypto = require('crypto');
const QRCode = require('qrcode');
const Group = require('../models/Group');
const User = require('../models/User');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');

const PIN_LENGTH = 6;
const MAX_PIN_ATTEMPTS = 8;
const JWT_SECRET = process.env.JWT_SECRET || 'changeme123';

// helper: generate random 6-digit PIN string (numeric)
async function generateUniquePin() {
  for (let i = 0; i < MAX_PIN_ATTEMPTS; i++) {
    const pin = Math.floor(Math.random() * 1000000).toString().padStart(PIN_LENGTH, '0');
    const exists = await Group.findOne({ pin }).lean();
    if (!exists) return pin;
  }
  // fallback unique-ish value (alphanumeric truncated)
  return crypto.randomBytes(4).toString('hex').slice(0, PIN_LENGTH).toUpperCase();
}

function getIo(req) {
  return (req && req.app && req.app.get && req.app.get('io')) || global.io || null;
}

// safe username generator (ensures uniqueness)
async function makeUniqueUsername(base) {
  const cleanBase = String(base || 'user').trim().replace(/\s+/g, '_').replace(/[^\w\-._]/g, '').slice(0, 30) || 'user';
  let candidate = cleanBase;
  let suffix = 0;
  while (await User.findOne({ username: candidate })) {
    suffix++;
    candidate = `${cleanBase}_${suffix}`;
    if (suffix > 1000) break;
  }
  return candidate;
}

// Create group (teacher only)
exports.createGroup = async (req, res) => {
  try {
    const user = req.user;
    if (!user) return res.status(401).json({ error: 'Authentication required' });

    const { groupName } = req.body;
    const finalName = (groupName && String(groupName).trim()) || `${user.username || user.name || 'Teacher'}'s Class`;

    const pin = await generateUniquePin();

    // QR payload: point to frontend with pin query param if FRONTEND_URL set
    const frontendUrl = (process.env.FRONTEND_URL || process.env.VITE_FRONTEND_URL || process.env.REACT_APP_FRONTEND_URL || '').trim();
    const qrPayload = frontendUrl ? `${frontendUrl.replace(/\/$/, '')}/?pin=${pin}` : `PIN:${pin}`;

    const qrDataUrl = await QRCode.toDataURL(qrPayload, { margin: 1, scale: 6 });

    const group = new Group({
      groupName: finalName,
      admin: mongoose.Types.ObjectId(user.id || user._id),
      members: [mongoose.Types.ObjectId(user.id || user._id)],
      pin,
      qrCode: qrDataUrl,
      isActive: true
    });

    await group.save();

    return res.status(201).json({ success: true, group });
  } catch (err) {
    console.error('createGroup err', err);
    return res.status(500).json({ error: 'Failed to create group' });
  }
};

// joinGroup: supports:
// - authenticated user (token present) => add to members
// - unauthenticated join with body { pin, name, email } => create or reuse student user, sign JWT, add to group, return token
exports.joinGroup = async (req, res) => {
  try {
    const payload = req.body || {};
    // support raw string body (legacy)
    const pin = (typeof payload === 'string' ? payload : payload?.pin) ?? payload?.pin;
    if (!pin) return res.status(400).json({ error: 'PIN is required' });

    const group = await Group.findOne({ pin })
      .populate('admin', 'username email')
      .populate('members', 'username email role')
      .exec();

    if (!group) return res.status(404).json({ error: 'Invalid PIN' });
    if (!group.isActive) return res.status(410).json({ error: 'This session is expired' });

    const reqUser = req.user;
    // --- if request is authenticated: add that user to group if needed ---
    if (reqUser && (reqUser.id || reqUser._id)) {
      const userIdStr = (reqUser.id || reqUser._id).toString();
      const already = group.members.some(m => (m._id ? m._id.toString() : m.toString()) === userIdStr);
      if (!already) {
        group.members.push(mongoose.Types.ObjectId(userIdStr));
        await group.save();
      }
      const io = getIo(req);
      if (io) io.emit('userJoined', { groupId: group._id, user: { id: userIdStr, username: reqUser.username || reqUser.name } });
      return res.json({ success: true, group });
    }

    // --- unauthenticated join flow (expected payload: name, email) ---
    const { name, email } = payload || {};
    if (!name || !email) {
      // frontend can show join UI asking for name/email after scanning QR; for now return group info
      return res.json({ success: true, group });
    }

    const emailNorm = String(email).trim().toLowerCase();
    // Try to reuse existing user by email
    let student = await User.findOne({ email: emailNorm }).exec();

    if (!student) {
      // create new guest student user
      const usernameCandidate = await makeUniqueUsername(name);
      // generate a random password so schema constraints satisfied; it's not used by guest
      const randomPass = crypto.randomBytes(6).toString('hex');
      student = new User({
        username: usernameCandidate,
        password: randomPass,
        email: emailNorm,
        role: 'student'
      });
      await student.save();
    }

    // Add to group members if not already
    const studentIdStr = student._id.toString();
    const isMember = group.members.some(m => (m._id ? m._id.toString() : m.toString()) === studentIdStr);
    if (!isMember) {
      group.members.push(mongoose.Types.ObjectId(studentIdStr));
      await group.save();
    }

    // Create JWT for this student so frontend can store token and access chat routes/socket
    const tokenPayload = { id: student._id.toString(), role: student.role || 'student' };
    const token = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: '24h' });

    // Emit socket event (best-effort)
    const io = getIo(req);
    if (io) {
      io.emit('userJoined', { groupId: group._id, user: { id: studentIdStr, username: student.username } });
    }

    // return token + user + group
    const safeUser = {
      id: student._id.toString(),
      username: student.username,
      email: student.email,
      role: student.role
    };

    return res.json({ success: true, token, user: safeUser, group });
  } catch (err) {
    console.error('joinGroup err', err);
    return res.status(500).json({ error: 'Failed to join group' });
  }
};

exports.getGroupDetails = async (req, res) => {
  try {
    const { groupId } = req.params;
    if (!groupId) return res.status(400).json({ error: 'groupId required' });

    const group = await Group.findById(groupId)
      .populate('admin', 'username email')
      .populate('members', 'username email role')
      .lean()
      .exec();

    if (!group) return res.status(404).json({ error: 'Group not found' });
    return res.json({ success: true, group });
  } catch (err) {
    console.error('getGroupDetails err', err);
    return res.status(500).json({ error: 'Failed to load group' });
  }
};

exports.getMyGroups = async (req, res) => {
  try {
    const user = req.user;
    if (!user) return res.status(401).json({ error: 'Authentication required' });

    const uid = mongoose.Types.ObjectId(user.id || user._id);
    const groups = await Group.find({
      $or: [
        { admin: uid },
        { members: uid }
      ]
    }).sort({ updatedAt: -1 }).lean().exec();

    return res.json({ success: true, groups });
  } catch (err) {
    console.error('getMyGroups err', err);
    return res.status(500).json({ error: 'Failed to load groups' });
  }
};

exports.endSession = async (req, res) => {
  try {
    const { groupId } = req.params;
    const user = req.user;
    if (!user) return res.status(401).json({ error: 'Authentication required' });
    if (!groupId) return res.status(400).json({ error: 'groupId required' });

    const group = await Group.findById(groupId);
    if (!group) return res.status(404).json({ error: 'Group not found' });

    const adminId = group.admin.toString();
    const userId = (user.id || user._id).toString();
    if (adminId !== userId) return res.status(403).json({ error: 'Only admin can end the session' });

    group.isActive = false;
    group.endedAt = new Date();
    await group.save();

    const io = getIo(req);
    if (io) {
      io.emit('sessionEnded', { groupId: group._id, pin: group.pin });
    }

    return res.json({ success: true, message: 'Session ended' });
  } catch (err) {
    console.error('endSession err', err);
    return res.status(500).json({ error: 'Failed to end session' });
  }
};
